import tkinter as tk
from tkinter import messagebox

class Application(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Object-Oriented Tkinter App")

        self.label = tk.Label(self, text="Welcome to the App!")
        self.label.pack()

        self.button = CustomButton(self, text="Click Me", command=self.on_click)
        self.button.pack()

    def on_click(self):
        self.label.config(text="Button Clicked!")
        self.button.display_message()

# Encapsulation: Each class encapsulates its data and behavior within itself.
# Polymorphism: CustomButton overrides the display_message method of Button class.
# Method Overriding: CustomButton overrides the display_message method of Button class.
# Multiple Inheritance: CustomButton inherits from tk.Button and also has its own class.

class CustomButton(tk.Button):
    def __init__(self, master=None, cnf={}, **kw):
        super().__init__(master, cnf, **kw)

    def display_message(self):
        messagebox.showinfo("Message", "Custom Button Clicked!")

# Decorator: Using a decorator to customize the behavior of the button.
# In this case, the button changes color when hovered over.

def hover_decorator(func):
    def wrapper(self, *args, **kwargs):
        self.bind("<Enter>", lambda e: self.config(bg="light blue"))
        self.bind("<Leave>", lambda e: self.config(bg="SystemButtonFace"))
        return func(self, *args, **kwargs)
    return wrapper

class HoverButton(tk.Button):
    def __init__(self, master=None, cnf={}, **kw):
        super().__init__(master, cnf, **kw)

    @hover_decorator
    def display_message(self):
        messagebox.showinfo("Message", "Hover Button Clicked!")

if _name_ == "_main_":
    app = Application()
    app.mainloop()