git clone https://github.com/Saguunn/python-S1.git
cd python-S1
git add .
git commit -m "Add task responses"
git push origin main
